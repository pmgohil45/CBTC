package com.pmgohil.unitconverter

import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.math.BigDecimal
import java.math.BigInteger

class MainActivity : AppCompatActivity() {

    private lateinit var inputEditText: EditText
    private lateinit var fromUnitSpinner: Spinner
    private lateinit var toUnitSpinner: Spinner
    private lateinit var categorySpinner: Spinner
    private lateinit var convertButton: Button
    private lateinit var resultTextView: TextView

    private val categories = arrayOf(
        "Length",
        "Area",
        "Volume",
        "Mass",
        "Speed",
        "Time",
        "Pressure",
        "Energy",
        "Power",
        "Digital Storage",
        "Fuel Consumption"
    )
    private val units = mapOf(
        "Length" to arrayOf(
            "Millimeters (mm)",
            "Centimeters (cm)",
            "Meters (m)",
            "Kilometers (km)",
            "Inches (in)",
            "Feet (ft)",
            "Yards (yd)",
            "Miles (mi)"
        ), "Area" to arrayOf(
            "Square millimeters (mm²)",
            "Square centimeters (cm²)",
            "Square meters (m²)",
            "Hectares (ha)",
            "Square kilometers (km²)",
            "Square inches (in²)",
            "Square feet (ft²)",
            "Square yards (yd²)",
            "Acres (ac)",
            "Square miles (mi²)"
        ), "Volume" to arrayOf(
            "Milliliters (ml)",
            "Centiliters (cl)",
            "Deciliters (dl)",
            "Liters (l)",
            "Cubic meters (m³)",
            "Teaspoons (tsp)",
            "Tablespoons (tbsp)",
            "Fluid ounces (fl oz)",
            "Cups",
            "Pints (pt)",
            "Quarts (qt)",
            "Gallons (gal)",
            "Cubic inches (in³)",
            "Cubic feet (ft³)",
            "Cubic yards (yd³)"
        ), "Mass" to arrayOf(
            "Milligrams (mg)",
            "Grams (g)",
            "Kilograms (kg)",
            "Metric tons (t)",
            "Ounces (oz)",
            "Pounds (lb)",
            "Stones (st)",
            "Short tons (US)",
            "Long tons (UK)"
        ), "Speed" to arrayOf(
            "Meters per second (m/s)",
            "Kilometers per hour (km/h)",
            "Miles per hour (mph)",
            "Feet per second (ft/s)",
            "Knots (nautical miles per hour)"
        ), "Time" to arrayOf(
            "Seconds (s)",
            "Minutes (min)",
            "Hours (h)",
            "Days (d)",
            "Weeks (wk)",
            "Months",
            "Years (yr)",
            "Decades",
            "Centuries"
        ), "Pressure" to arrayOf(
            "Pascals (Pa)",
            "Kilopascals (kPa)",
            "Megapascals (MPa)",
            "Bar",
            "Atmospheres (atm)",
            "Pounds per square inch (psi)",
            "Torr (mmHg)"
        ), "Energy" to arrayOf(
            "Joules (J)",
            "Kilojoules (kJ)",
            "Calories (cal)",
            "Kilocalories (kcal)",
            "Watt hours (Wh)",
            "Kilowatt hours (kWh)",
            "British thermal units (BTU)",
            "Electronvolts (eV)"
        ), "Power" to arrayOf(
            "Watts (W)", "Kilowatts (kW)", "Megawatts (MW)", "Gigawatts (GW)", "Horsepower (hp)"
        ), "Digital Storage" to arrayOf(
            "Bits (b)",
            "Bytes (B)",
            "Kilobytes (KB)",
            "Megabytes (MB)",
            "Gigabytes (GB)",
            "Terabytes (TB)",
            "Petabytes (PB)"
        ), "Fuel Consumption" to arrayOf(
            "Liters per 100 kilometers (L/100km)",
            "Miles per gallon (MPG, US)",
            "Miles per gallon (MPG, UK)"
        )
    )
    private val conversions = mapOf(
        "Length" to mapOf(
            "Millimeters (mm)" to mapOf(
                "Centimeters (cm)" to 0.1,
                "Meters (m)" to 0.001,
                "Kilometers (km)" to 0.000001,
                "Inches (in)" to 0.0393701,
                "Feet (ft)" to 0.00328084,
                "Yards (yd)" to 0.00109361,
                "Miles (mi)" to 0.00000621371
            ), "Centimeters (cm)" to mapOf(
                "Millimeters (mm)" to 10.0,
                "Meters (m)" to 0.01,
                "Kilometers (km)" to 0.00001,
                "Inches (in)" to 0.393701,
                "Feet (ft)" to 0.0328084,
                "Yards (yd)" to 0.0109361,
                "Miles (mi)" to 0.0000621371
            ), "Meters (m)" to mapOf(
                "Millimeters (mm)" to 1000.0,
                "Centimeters (cm)" to 100.0,
                "Kilometers (km)" to 0.001,
                "Inches (in)" to 39.3701,
                "Feet (ft)" to 3.28084,
                "Yards (yd)" to 1.09361,
                "Miles (mi)" to 0.000621371
            ), "Kilometers (km)" to mapOf(
                "Millimeters (mm)" to 1000000.0,
                "Centimeters (cm)" to 100000.0,
                "Meters (m)" to 1000.0,
                "Inches (in)" to 39370.1,
                "Feet (ft)" to 3280.84,
                "Yards (yd)" to 1093.61,
                "Miles (mi)" to 0.621371
            ), "Inches (in)" to mapOf(
                "Millimeters (mm)" to 25.4,
                "Centimeters (cm)" to 2.54,
                "Meters (m)" to 0.0254,
                "Kilometers (km)" to 0.0000254,
                "Feet (ft)" to 0.0833333,
                "Yards (yd)" to 0.0277778,
                "Miles (mi)" to 0.000015783
            ), "Feet (ft)" to mapOf(
                "Millimeters (mm)" to 304.8,
                "Centimeters (cm)" to 30.48,
                "Meters (m)" to 0.3048,
                "Kilometers (km)" to 0.0003048,
                "Inches (in)" to 12.0,
                "Yards (yd)" to 0.3333333,
                "Miles (mi)" to 0.000189394
            ), "Yards (yd)" to mapOf(
                "Millimeters (mm)" to 914.4,
                "Centimeters (cm)" to 91.44,
                "Meters (m)" to 0.9144,
                "Kilometers (km)" to 0.0009144,
                "Inches (in)" to 36.0,
                "Feet (ft)" to 3.0,
                "Miles (mi)" to 0.000568182
            ), "Miles (mi)" to mapOf(
                "Millimeters (mm)" to 1609344.0,
                "Centimeters (cm)" to 160934.4,
                "Meters (m)" to 1609.344,
                "Kilometers (km)" to 1.609344,
                "Inches (in)" to 63360.0,
                "Feet (ft)" to 5280.0,
                "Yards (yd)" to 1760.0
            )
        ), "Area" to mapOf(
            "Square millimeters (mm²)" to mapOf(
                "Square centimeters (cm²)" to 0.01,
                "Square meters (m²)" to 0.000001,
                "Hectares (ha)" to 0.00000001,
                "Square kilometers (km²)" to 0.0000000001,
                "Square inches (in²)" to 0.001550003,
                "Square feet (ft²)" to 0.0000107639,
                "Square yards (yd²)" to 0.000000836127,
                "Acres (ac)" to 0.00000000404686,
                "Square miles (mi²)" to 0.0000000000038612
            ), "Square centimeters (cm²)" to mapOf(
                "Square millimeters (mm²)" to 100.0,
                "Square meters (m²)" to 0.0001,
                "Hectares (ha)" to 0.000001,
                "Square kilometers (km²)" to 0.00000001,
                "Square inches (in²)" to 0.1550003,
                "Square feet (ft²)" to 0.00107639,
                "Square yards (yd²)" to 0.000119599,
                "Acres (ac)" to 0.0000000247105,
                "Square miles (mi²)" to 0.0000000000386102
            ), "Square meters (m²)" to mapOf(
                "Square millimeters (mm²)" to 1000000.0,
                "Square centimeters (cm²)" to 10000.0,
                "Hectares (ha)" to 0.0001,
                "Square kilometers (km²)" to 0.000001,
                "Square inches (in²)" to 1550.003,
                "Square feet (ft²)" to 10.7639,
                "Square yards (yd²)" to 1.19599,
                "Acres (ac)" to 0.000247105,
                "Square miles (mi²)" to 0.000000386102
            ), "Hectares (ha)" to mapOf(
                "Square millimeters (mm²)" to 10000000000.0,
                "Square centimeters (cm²)" to 100000000.0,
                "Square meters (m²)" to 10000.0,
                "Square kilometers (km²)" to 0.01,
                "Square inches (in²)" to 15500031.0,
                "Square feet (ft²)" to 107639.0,
                "Square yards (yd²)" to 11959.9,
                "Acres (ac)" to 2.47105,
                "Square miles (mi²)" to 0.00386102
            ), "Square kilometers (km²)" to mapOf(
                "Square millimeters (mm²)" to 1000000000000.0,
                "Square centimeters (cm²)" to 10000000000.0,
                "Square meters (m²)" to 1000000.0,
                "Hectares (ha)" to 100.0,
                "Square inches (in²)" to 1550003100.0,
                "Square feet (ft²)" to 10763910.0,
                "Square yards (yd²)" to 1195990.0,
                "Acres (ac)" to 247.105,
                "Square miles (mi²)" to 0.386102
            ), "Square inches (in²)" to mapOf(
                "Square millimeters (mm²)" to 645.16,
                "Square centimeters (cm²)" to 6.4516,
                "Square meters (m²)" to 0.00064516,
                "Hectares (ha)" to 0.000000064516,
                "Square kilometers (km²)" to 0.00000000064516,
                "Square feet (ft²)" to 0.00694444,
                "Square yards (yd²)" to 0.000771605,
                "Acres (ac)" to 0.00000015942,
                "Square miles (mi²)" to 0.000000000249097
            ), "Square feet (ft²)" to mapOf(
                "Square millimeters (mm²)" to 92903.0,
                "Square centimeters (cm²)" to 929.03,
                "Square meters (m²)" to 0.092903,
                "Hectares (ha)" to 0.0000092903,
                "Square kilometers (km²)" to 0.000000092903,
                "Square inches (in²)" to 144.0,
                "Square yards (yd²)" to 0.111111,
                "Acres (ac)" to 0.0000229568,
                "Square miles (mi²)" to 0.0000000358701
            ), "Square yards (yd²)" to mapOf(
                "Square millimeters (mm²)" to 836127.0,
                "Square centimeters (cm²)" to 8361.27,
                "Square meters (m²)" to 0.836127,
                "Hectares (ha)" to 0.0000836127,
                "Square kilometers (km²)" to 0.000000836127,
                "Square inches (in²)" to 1296.0,
                "Square feet (ft²)" to 9.0,
                "Acres (ac)" to 0.000206612,
                "Square miles (mi²)" to 0.000000322831
            ), "Acres (ac)" to mapOf(
                "Square millimeters (mm²)" to 4046860000.0,
                "Square centimeters (cm²)" to 40468600.0,
                "Square meters (m²)" to 4046.86,
                "Hectares (ha)" to 0.404686,
                "Square kilometers (km²)" to 0.00404686,
                "Square inches (in²)" to 6272640.0,
                "Square feet (ft²)" to 43560.0,
                "Square yards (yd²)" to 4840.0,
                "Square miles (mi²)" to 0.0015625
            ), "Square miles (mi²)" to mapOf(
                "Square millimeters (mm²)" to 2589988000000.0,
                "Square centimeters (cm²)" to 25899880000.0,
                "Square meters (m²)" to 2589988.0,
                "Hectares (ha)" to 258.9988,
                "Square kilometers (km²)" to 2.589988,
                "Square inches (in²)" to 4014489600.0,
                "Square feet (ft²)" to 27878400.0,
                "Square yards (yd²)" to 3097600.0,
                "Acres (ac)" to 640.0
            )
        ), "Volume" to mapOf(
            "Milliliters (ml)" to mapOf(
                "Centiliters (cl)" to 0.1,
                "Deciliters (dl)" to 0.01,
                "Liters (l)" to 0.001,
                "Cubic meters (m³)" to 0.000001,
                "Teaspoons (tsp)" to 0.202884,
                "Tablespoons (tbsp)" to 0.067628,
                "Fluid ounces (fl oz)" to 0.033814,
                "Cups" to 0.00422675,
                "Pints (pt)" to 0.00211338,
                "Quarts (qt)" to 0.00105669,
                "Gallons (gal)" to 0.000264172,
                "Cubic inches (in³)" to 0.0610237,
                "Cubic feet (ft³)" to 0.0000353147,
                "Cubic yards (yd³)" to 0.00000130795
            ), "Centiliters (cl)" to mapOf(
                "Milliliters (ml)" to 10.0,
                "Deciliters (dl)" to 0.1,
                "Liters (l)" to 0.01,
                "Cubic meters (m³)" to 0.00001,
                "Teaspoons (tsp)" to 2.02884,
                "Tablespoons (tbsp)" to 0.67628,
                "Fluid ounces (fl oz)" to 0.33814,
                "Cups" to 0.0422675,
                "Pints (pt)" to 0.0211338,
                "Quarts (qt)" to 0.0105669,
                "Gallons (gal)" to 0.00264172,
                "Cubic inches (in³)" to 0.610237,
                "Cubic feet (ft³)" to 0.000353147,
                "Cubic yards (yd³)" to 0.0000130795
            ), "Deciliters (dl)" to mapOf(
                "Milliliters (ml)" to 100.0,
                "Centiliters (cl)" to 10.0,
                "Liters (l)" to 0.1,
                "Cubic meters (m³)" to 0.0001,
                "Teaspoons (tsp)" to 20.2884,
                "Tablespoons (tbsp)" to 6.7628,
                "Fluid ounces (fl oz)" to 3.3814,
                "Cups" to 0.422675,
                "Pints (pt)" to 0.211338,
                "Quarts (qt)" to 0.105669,
                "Gallons (gal)" to 0.0264172,
                "Cubic inches (in³)" to 6.10237,
                "Cubic feet (ft³)" to 0.00353147,
                "Cubic yards (yd³)" to 0.000130795
            ), "Liters (l)" to mapOf(
                "Milliliters (ml)" to 1000.0,
                "Centiliters (cl)" to 100.0,
                "Deciliters (dl)" to 10.0,
                "Cubic meters (m³)" to 0.001,
                "Teaspoons (tsp)" to 202.884,
                "Tablespoons (tbsp)" to 67.628,
                "Fluid ounces (fl oz)" to 33.814,
                "Cups" to 4.22675,
                "Pints (pt)" to 2.11338,
                "Quarts (qt)" to 1.05669,
                "Gallons (gal)" to 0.264172,
                "Cubic inches (in³)" to 61.0237,
                "Cubic feet (ft³)" to 0.0353147,
                "Cubic yards (yd³)" to 0.00130795
            ), "Cubic meters (m³)" to mapOf(
                "Milliliters (ml)" to 1000000.0,
                "Centiliters (cl)" to 100000.0,
                "Deciliters (dl)" to 10000.0,
                "Liters (l)" to 1000.0,
                "Teaspoons (tsp)" to 202884.0,
                "Tablespoons (tbsp)" to 67628.0,
                "Fluid ounces (fl oz)" to 33814.0,
                "Cups" to 4226.75,
                "Pints (pt)" to 2113.38,
                "Quarts (qt)" to 1056.69,
                "Gallons (gal)" to 264.172,
                "Cubic inches (in³)" to 61023.7,
                "Cubic feet (ft³)" to 35.3147,
                "Cubic yards (yd³)" to 1.30795
            ), "Teaspoons (tsp)" to mapOf(
                "Milliliters (ml)" to 4.92892,
                "Centiliters (cl)" to 0.492892,
                "Deciliters (dl)" to 0.0492892,
                "Liters (l)" to 0.00492892,
                "Cubic meters (m³)" to 0.00000492892,
                "Tablespoons (tbsp)" to 0.333333,
                "Fluid ounces (fl oz)" to 0.166667,
                "Cups" to 0.0208333,
                "Pints (pt)" to 0.0104167,
                "Quarts (qt)" to 0.00520833,
                "Gallons (gal)" to 0.00130208,
                "Cubic inches (in³)" to 0.300781,
                "Cubic feet (ft³)" to 0.000173956,
                "Cubic yards (yd³)" to 0.00000643741
            ), "Tablespoons (tbsp)" to mapOf(
                "Milliliters (ml)" to 14.7868,
                "Centiliters (cl)" to 1.47868,
                "Deciliters (dl)" to 0.147868,
                "Liters (l)" to 0.0147868,
                "Cubic meters (m³)" to 0.0000147868,
                "Teaspoons (tsp)" to 3.0,
                "Fluid ounces (fl oz)" to 0.5,
                "Cups" to 0.0625,
                "Pints (pt)" to 0.03125,
                "Quarts (qt)" to 0.015625,
                "Gallons (gal)" to 0.00390625,
                "Cubic inches (in³)" to 0.902344,
                "Cubic feet (ft³)" to 0.00052219,
                "Cubic yards (yd³)" to 0.0000193405
            ), "Fluid ounces (fl oz)" to mapOf(
                "Milliliters (ml)" to 29.5735,
                "Centiliters (cl)" to 2.95735,
                "Deciliters (dl)" to 0.295735,
                "Liters (l)" to 0.0295735,
                "Cubic meters (m³)" to 0.0000295735,
                "Teaspoons (tsp)" to 6.0,
                "Tablespoons (tbsp)" to 2.0,
                "Cups" to 0.125,
                "Pints (pt)" to 0.0625,
                "Quarts (qt)" to 0.03125,
                "Gallons (gal)" to 0.0078125,
                "Cubic inches (in³)" to 1.80469,
                "Cubic feet (ft³)" to 0.00104438,
                "Cubic yards (yd³)" to 0.0000386439
            ), "Cups" to mapOf(
                "Milliliters (ml)" to 236.588,
                "Centiliters (cl)" to 23.6588,
                "Deciliters (dl)" to 2.36588,
                "Liters (l)" to 0.236588,
                "Cubic meters (m³)" to 0.000236588,
                "Teaspoons (tsp)" to 48.0,
                "Tablespoons (tbsp)" to 16.0,
                "Fluid ounces (fl oz)" to 8.0,
                "Pints (pt)" to 0.5,
                "Quarts (qt)" to 0.25,
                "Gallons (gal)" to 0.0625,
                "Cubic inches (in³)" to 14.6457,
                "Cubic feet (ft³)" to 0.00835503,
                "Cubic yards (yd³)" to 0.00030944
            ), "Pints (pt)" to mapOf(
                "Milliliters (ml)" to 473.176,
                "Centiliters (cl)" to 47.3176,
                "Deciliters (dl)" to 4.73176,
                "Liters (l)" to 0.473176,
                "Cubic meters (m³)" to 0.000473176,
                "Teaspoons (tsp)" to 96.0,
                "Tablespoons (tbsp)" to 32.0,
                "Fluid ounces (fl oz)" to 16.0,
                "Cups" to 2.0,
                "Quarts (qt)" to 0.5,
                "Gallons (gal)" to 0.125,
                "Cubic inches (in³)" to 29.2913,
                "Cubic feet (ft³)" to 0.0167101,
                "Cubic yards (yd³)" to 0.000618891
            ), "Quarts (qt)" to mapOf(
                "Milliliters (ml)" to 946.353,
                "Centiliters (cl)" to 94.6353,
                "Deciliters (dl)" to 9.46353,
                "Liters (l)" to 0.946353,
                "Cubic meters (m³)" to 0.000946353,
                "Teaspoons (tsp)" to 192.0,
                "Tablespoons (tbsp)" to 64.0,
                "Fluid ounces (fl oz)" to 32.0,
                "Cups" to 4.0,
                "Pints (pt)" to 2.0,
                "Gallons (gal)" to 0.25,
                "Cubic inches (in³)" to 58.5823,
                "Cubic feet (ft³)" to 0.0334201,
                "Cubic yards (yd³)" to 0.00123778
            ), "Gallons (gal)" to mapOf(
                "Milliliters (ml)" to 3785.41,
                "Centiliters (cl)" to 378.541,
                "Deciliters (dl)" to 37.8541,
                "Liters (l)" to 3.78541,
                "Cubic meters (m³)" to 0.00378541,
                "Teaspoons (tsp)" to 768.0,
                "Tablespoons (tbsp)" to 256.0,
                "Fluid ounces (fl oz)" to 128.0,
                "Cups" to 16.0,
                "Pints (pt)" to 8.0,
                "Quarts (qt)" to 4.0,
                "Cubic inches (in³)" to 231.0,
                "Cubic feet (ft³)" to 0.133681,
                "Cubic yards (yd³)" to 0.00495113
            ), "Cubic inches (in³)" to mapOf(
                "Milliliters (ml)" to 16.3871,
                "Centiliters (cl)" to 1.63871,
                "Deciliters (dl)" to 0.163871,
                "Liters (l)" to 0.0163871,
                "Cubic meters (m³)" to 0.0000163871,
                "Teaspoons (tsp)" to 3.32468,
                "Tablespoons (tbsp)" to 1.10823,
                "Fluid ounces (fl oz)" to 0.554112,
                "Cups" to 0.0692641,
                "Pints (pt)" to 0.034632,
                "Quarts (qt)" to 0.017316,
                "Gallons (gal)" to 0.004329,
                "Cubic feet (ft³)" to 0.000578704,
                "Cubic yards (yd³)" to 0.0000214335
            ), "Cubic feet (ft³)" to mapOf(
                "Milliliters (ml)" to 28316.8,
                "Centiliters (cl)" to 2831.68,
                "Deciliters (dl)" to 283.168,
                "Liters (l)" to 28.3168,
                "Cubic meters (m³)" to 0.0283168,
                "Teaspoons (tsp)" to 5745.04,
                "Tablespoons (tbsp)" to 1915.01,
                "Fluid ounces (fl oz)" to 957.506,
                "Cups" to 119.688,
                "Pints (pt)" to 59.8442,
                "Quarts (qt)" to 29.9221,
                "Gallons (gal)" to 7.48052,
                "Cubic inches (in³)" to 1728.0,
                "Cubic yards (yd³)" to 0.037037
            ), "Cubic yards (yd³)" to mapOf(
                "Milliliters (ml)" to 764555.0,
                "Centiliters (cl)" to 76455.5,
                "Deciliters (dl)" to 7645.55,
                "Liters (l)" to 764.555,
                "Cubic meters (m³)" to 0.764555,
                "Teaspoons (tsp)" to 155252.0,
                "Tablespoons (tbsp)" to 51750.7,
                "Fluid ounces (fl oz)" to 25875.3,
                "Cups" to 3234.41,
                "Pints (pt)" to 1617.2,
                "Quarts (qt)" to 808.601,
                "Gallons (gal)" to 202.15,
                "Cubic inches (in³)" to 46656.0,
                "Cubic feet (ft³)" to 27.0
            )
        ), "Mass" to mapOf(
            "Milligrams (mg)" to mapOf(
                "Grams (g)" to 0.001,
                "Kilograms (kg)" to 0.000001,
                "Metric tons (t)" to 0.000000001,
                "Ounces (oz)" to 0.000035274,
                "Pounds (lb)" to 0.00000220462,
                "Stones (st)" to 0.000000157473,
                "Short tons (US)" to 0.00000000110231,
                "Long tons (UK)" to 0.000000000984207
            ), "Grams (g)" to mapOf(
                "Milligrams (mg)" to 1000.0,
                "Kilograms (kg)" to 0.001,
                "Metric tons (t)" to 0.000001,
                "Ounces (oz)" to 0.035274,
                "Pounds (lb)" to 0.00220462,
                "Stones (st)" to 0.000157473,
                "Short tons (US)" to 0.00000110231,
                "Long tons (UK)" to 0.000000984207
            ), "Kilograms (kg)" to mapOf(
                "Milligrams (mg)" to 1000000.0,
                "Grams (g)" to 1000.0,
                "Metric tons (t)" to 0.001,
                "Ounces (oz)" to 35.274,
                "Pounds (lb)" to 2.20462,
                "Stones (st)" to 0.157473,
                "Short tons (US)" to 0.00110231,
                "Long tons (UK)" to 0.000984207
            ), "Metric tons (t)" to mapOf(
                "Milligrams (mg)" to 1000000000.0,
                "Grams (g)" to 1000000.0,
                "Kilograms (kg)" to 1000.0,
                "Ounces (oz)" to 35274.0,
                "Pounds (lb)" to 2204.62,
                "Stones (st)" to 157.473,
                "Short tons (US)" to 1.10231,
                "Long tons (UK)" to 0.984207
            ), "Ounces (oz)" to mapOf(
                "Milligrams (mg)" to 28349.5,
                "Grams (g)" to 28.3495,
                "Kilograms (kg)" to 0.0283495,
                "Metric tons (t)" to 0.0000283495,
                "Pounds (lb)" to 0.0625,
                "Stones (st)" to 0.00446429,
                "Short tons (US)" to 0.00003125,
                "Long tons (UK)" to 0.0000279018
            ), "Pounds (lb)" to mapOf(
                "Milligrams (mg)" to 453592.0,
                "Grams (g)" to 453.592,
                "Kilograms (kg)" to 0.453592,
                "Metric tons (t)" to 0.000453592,
                "Ounces (oz)" to 16.0,
                "Stones (st)" to 0.0714286,
                "Short tons (US)" to 0.0005,
                "Long tons (UK)" to 0.000446429
            ), "Stones (st)" to mapOf(
                "Milligrams (mg)" to 6350290.0,
                "Grams (g)" to 6350.29,
                "Kilograms (kg)" to 6.35029,
                "Metric tons (t)" to 0.00635029,
                "Ounces (oz)" to 224.0,
                "Pounds (lb)" to 14.0,
                "Short tons (US)" to 0.007,
                "Long tons (UK)" to 0.00625
            ), "Short tons (US)" to mapOf(
                "Milligrams (mg)" to 907185000.0,
                "Grams (g)" to 907185.0,
                "Kilograms (kg)" to 907.185,
                "Metric tons (t)" to 0.907185,
                "Ounces (oz)" to 32000.0,
                "Pounds (lb)" to 2000.0,
                "Stones (st)" to 142.857,
                "Long tons (UK)" to 0.892857
            ), "Long tons (UK)" to mapOf(
                "Milligrams (mg)" to 1016000000.0,
                "Grams (g)" to 1016000.0,
                "Kilograms (kg)" to 1016.0,
                "Metric tons (t)" to 1.016,
                "Ounces (oz)" to 35840.0,
                "Pounds (lb)" to 2240.0,
                "Stones (st)" to 160.0,
                "Short tons (US)" to 1.12
            )
        ), "Speed" to mapOf(
            "Meters per second (m/s)" to mapOf(
                "Kilometers per hour (km/h)" to 3.6,
                "Miles per hour (mph)" to 2.23694,
                "Feet per second (ft/s)" to 3.28084,
                "Knots (nautical miles per hour)" to 1.94384,
                "Inches per second (in/s)" to 39.3701,
                "Yards per second (yd/s)" to 1.09361
            ), "Kilometers per hour (km/h)" to mapOf(
                "Meters per second (m/s)" to 0.277778,
                "Miles per hour (mph)" to 0.621371,
                "Feet per second (ft/s)" to 0.911344,
                "Knots (nautical miles per hour)" to 0.539957,
                "Inches per second (in/s)" to 10.9361,
                "Yards per second (yd/s)" to 0.303785
            ), "Miles per hour (mph)" to mapOf(
                "Meters per second (m/s)" to 0.44704,
                "Kilometers per hour (km/h)" to 1.60934,
                "Feet per second (ft/s)" to 1.46667,
                "Knots (nautical miles per hour)" to 0.868976,
                "Inches per second (in/s)" to 17.6,
                "Yards per second (yd/s)" to 0.491237
            ), "Feet per second (ft/s)" to mapOf(
                "Meters per second (m/s)" to 0.3048,
                "Kilometers per hour (km/h)" to 1.09728,
                "Miles per hour (mph)" to 0.681818,
                "Knots (nautical miles per hour)" to 0.592484,
                "Inches per second (in/s)" to 12,
                "Yards per second (yd/s)" to 0.333333
            ), "Knots (nautical miles per hour)" to mapOf(
                "Meters per second (m/s)" to 0.514444,
                "Kilometers per hour (km/h)" to 1.852,
                "Miles per hour (mph)" to 1.15078,
                "Feet per second (ft/s)" to 1.68781,
                "Inches per second (in/s)" to 20.2537,
                "Yards per second (yd/s)" to 0.463033
            ), "Inches per second (in/s)" to mapOf(
                "Meters per second (m/s)" to 0.0254,
                "Kilometers per hour (km/h)" to 0.09144,
                "Miles per hour (mph)" to 0.056818,
                "Feet per second (ft/s)" to 0.083333,
                "Knots (nautical miles per hour)" to 0.049373,
                "Yards per second (yd/s)" to 0.027778
            ), "Yards per second (yd/s)" to mapOf(
                "Meters per second (m/s)" to 0.9144,
                "Kilometers per hour (km/h)" to 3.29184,
                "Miles per hour (mph)" to 2.03694,
                "Feet per second (ft/s)" to 3,
                "Knots (nautical miles per hour)" to 0.868976,
                "Inches per second (in/s)" to 36
            )
        ), "Time" to mapOf(
            "Seconds (s)" to mapOf(
                "Minutes (min)" to 0.0166667,
                "Hours (h)" to 0.000277778,
                "Days (d)" to 0.0000115741,
                "Weeks (wk)" to 0.00000165344,
                "Months" to 0.000000380517,
                "Years (yr)" to 0.0000000316881,
                "Decades" to 0.00000000316881,
                "Centuries" to 0.000000000316881
            ), "Minutes (min)" to mapOf(
                "Seconds (s)" to 60.0,
                "Hours (h)" to 0.0166667,
                "Days (d)" to 0.000694444,
                "Weeks (wk)" to 0.0000992063,
                "Months" to 0.0000228154,
                "Years (yr)" to 0.00000190261,
                "Decades" to 0.000000190261,
                "Centuries" to 0.0000000190261
            ), "Hours (h)" to mapOf(
                "Seconds (s)" to 3600.0,
                "Minutes (min)" to 60.0,
                "Days (d)" to 0.0416667,
                "Weeks (wk)" to 0.00595238,
                "Months" to 0.00136895,
                "Years (yr)" to 0.000114079,
                "Decades" to 0.0000114079,
                "Centuries" to 0.00000114079
            ), "Days (d)" to mapOf(
                "Seconds (s)" to 86400.0,
                "Minutes (min)" to 1440.0,
                "Hours (h)" to 24.0,
                "Weeks (wk)" to 0.142857,
                "Months" to 0.0328767,
                "Years (yr)" to 0.00273791,
                "Decades" to 0.000273791,
                "Centuries" to 0.0000273791
            ), "Weeks (wk)" to mapOf(
                "Seconds (s)" to 604800.0,
                "Minutes (min)" to 10080.0,
                "Hours (h)" to 168.0,
                "Days (d)" to 7.0,
                "Months" to 0.230769,
                "Years (yr)" to 0.0191781,
                "Decades" to 0.00191781,
                "Centuries" to 0.000191781
            ), "Months" to mapOf(
                "Seconds (s)" to 2629800.0,
                "Minutes (min)" to 43830.0,
                "Hours (h)" to 730.0,
                "Days (d)" to 30.4375,
                "Weeks (wk)" to 4.34821,
                "Years (yr)" to 0.0833333,
                "Decades" to 0.00833333,
                "Centuries" to 0.0000833333
            ), "Years (yr)" to mapOf(
                "Seconds (s)" to 31536000.0,
                "Minutes (min)" to 525600.0,
                "Hours (h)" to 8760.0,
                "Days (d)" to 365.25,
                "Weeks (wk)" to 52.1786,
                "Months" to 12.0,
                "Decades" to 0.1,
                "Centuries" to 0.01
            ), "Decades" to mapOf(
                "Seconds (s)" to 315360000.0,
                "Minutes (min)" to 5256000.0,
                "Hours (h)" to 87600.0,
                "Days (d)" to 3652.5,
                "Weeks (wk)" to 521.786,
                "Months" to 120.0,
                "Years (yr)" to 10.0,
                "Centuries" to 0.1
            ), "Centuries" to mapOf(
                "Seconds (s)" to 3153600000.0,
                "Minutes (min)" to 52560000.0,
                "Hours (h)" to 876000.0,
                "Days (d)" to 36525.0,
                "Weeks (wk)" to 5217.86,
                "Months" to 1200.0,
                "Years (yr)" to 100.0,
                "Decades" to 10.0
            )
        ), "Pressure" to mapOf(
            "Pascals (Pa)" to mapOf(
                "Kilopascals (kPa)" to 0.001,
                "Megapascals (MPa)" to 0.000001,
                "Bar" to 0.00001,
                "Atmospheres (atm)" to 0.00000986923,
                "Pounds per square inch (psi)" to 0.000145038,
                "Torr (mmHg)" to 0.00750062
            ), "Kilopascals (kPa)" to mapOf(
                "Pascals (Pa)" to 1000.0,
                "Megapascals (MPa)" to 0.001,
                "Bar" to 0.01,
                "Atmospheres (atm)" to 0.00986923,
                "Pounds per square inch (psi)" to 0.145038,
                "Torr (mmHg)" to 7.50062
            ), "Megapascals (MPa)" to mapOf(
                "Pascals (Pa)" to 1000000.0,
                "Kilopascals (kPa)" to 1000.0,
                "Bar" to 10.0,
                "Atmospheres (atm)" to 9.86923,
                "Pounds per square inch (psi)" to 145.038,
                "Torr (mmHg)" to 7500.62
            ), "Bar" to mapOf(
                "Pascals (Pa)" to 100000.0,
                "Kilopascals (kPa)" to 100.0,
                "Megapascals (MPa)" to 0.1,
                "Atmospheres (atm)" to 0.986923,
                "Pounds per square inch (psi)" to 14.5038,
                "Torr (mmHg)" to 750.062
            ), "Atmospheres (atm)" to mapOf(
                "Pascals (Pa)" to 101325.0,
                "Kilopascals (kPa)" to 101.325,
                "Megapascals (MPa)" to 0.101325,
                "Bar" to 1.01325,
                "Pounds per square inch (psi)" to 14.6959,
                "Torr (mmHg)" to 760.0
            ), "Pounds per square inch (psi)" to mapOf(
                "Pascals (Pa)" to 6894.76,
                "Kilopascals (kPa)" to 6.89476,
                "Megapascals (MPa)" to 0.00689476,
                "Bar" to 0.0689476,
                "Atmospheres (atm)" to 0.0680459,
                "Torr (mmHg)" to 51.7149
            ), "Torr (mmHg)" to mapOf(
                "Pascals (Pa)" to 133.322,
                "Kilopascals (kPa)" to 0.133322,
                "Megapascals (MPa)" to 0.000133322,
                "Bar" to 0.00133322,
                "Atmospheres (atm)" to 0.00131579,
                "Pounds per square inch (psi)" to 0.0193367
            )
        ), "Energy" to mapOf(
            "Joules (J)" to mapOf(
                "Kilojoules (kJ)" to 0.001,
                "Calories (cal)" to 0.239006,
                "Kilocalories (kcal)" to 0.000239006,
                "Watt hours (Wh)" to 0.000277778,
                "Kilowatt hours (kWh)" to 0.000000277778,
                "British thermal units (BTU)" to 0.000947817,
                "Electronvolts (eV)" to 6.242e+18
            ), "Kilojoules (kJ)" to mapOf(
                "Joules (J)" to 1000.0,
                "Calories (cal)" to 239.006,
                "Kilocalories (kcal)" to 0.239006,
                "Watt hours (Wh)" to 0.277778,
                "Kilowatt hours (kWh)" to 0.000277778,
                "British thermal units (BTU)" to 0.947817,
                "Electronvolts (eV)" to 6.242e+21
            ), "Calories (cal)" to mapOf(
                "Joules (J)" to 4.184,
                "Kilojoules (kJ)" to 0.004184,
                "Kilocalories (kcal)" to 0.001,
                "Watt hours (Wh)" to 0.00116222,
                "Kilowatt hours (kWh)" to 0.00000116222,
                "British thermal units (BTU)" to 0.00396567,
                "Electronvolts (eV)" to 2.611e+19
            ), "Kilocalories (kcal)" to mapOf(
                "Joules (J)" to 4184.0,
                "Kilojoules (kJ)" to 4.184,
                "Calories (cal)" to 1000.0,
                "Watt hours (Wh)" to 1.16222,
                "Kilowatt hours (kWh)" to 0.00116222,
                "British thermal units (BTU)" to 3.96567,
                "Electronvolts (eV)" to 2.611e+22
            ), "Watt hours (Wh)" to mapOf(
                "Joules (J)" to 3600.0,
                "Kilojoules (kJ)" to 3.6,
                "Calories (cal)" to 859.845,
                "Kilocalories (kcal)" to 0.859845,
                "Kilowatt hours (kWh)" to 0.001,
                "British thermal units (BTU)" to 3.41214,
                "Electronvolts (eV)" to 2.247e+22
            ), "Kilowatt hours (kWh)" to mapOf(
                "Joules (J)" to 3600000.0,
                "Kilojoules (kJ)" to 3600.0,
                "Calories (cal)" to 859845.0,
                "Kilocalories (kcal)" to 859.845,
                "Watt hours (Wh)" to 1000.0,
                "British thermal units (BTU)" to 3412.14,
                "Electronvolts (eV)" to 2.247e+25
            ), "British thermal units (BTU)" to mapOf(
                "Joules (J)" to 1055.06,
                "Kilojoules (kJ)" to 1.05506,
                "Calories (cal)" to 252.164,
                "Kilocalories (kcal)" to 0.252164,
                "Watt hours (Wh)" to 0.293071,
                "Kilowatt hours (kWh)" to 0.000293071,
                "Electronvolts (eV)" to 6.585e+21
            ), "Electronvolts (eV)" to mapOf(
                "Joules (J)" to 1.602e-19,
                "Kilojoules (kJ)" to 1.602e-22,
                "Calories (cal)" to 3.827e-20,
                "Kilocalories (kcal)" to 3.827e-23,
                "Watt hours (Wh)" to 4.451e-23,
                "Kilowatt hours (kWh)" to 4.451e-26,
                "British thermal units (BTU)" to 1.519e-22
            )
        ), "Power" to mapOf(
            "Watts (W)" to mapOf(
                "Kilowatts (kW)" to 0.001,
                "Megawatts (MW)" to 0.000001,
                "Gigawatts (GW)" to 0.000000001,
                "Horsepower (hp)" to 0.00134102
            ), "Kilowatts (kW)" to mapOf(
                "Watts (W)" to 1000.0,
                "Megawatts (MW)" to 0.001,
                "Gigawatts (GW)" to 0.000001,
                "Horsepower (hp)" to 1.34102
            ), "Megawatts (MW)" to mapOf(
                "Watts (W)" to 1000000.0,
                "Kilowatts (kW)" to 1000.0,
                "Gigawatts (GW)" to 0.001,
                "Horsepower (hp)" to 1341.02
            ), "Gigawatts (GW)" to mapOf(
                "Watts (W)" to 1000000000.0,
                "Kilowatts (kW)" to 1000000.0,
                "Megawatts (MW)" to 1000.0,
                "Horsepower (hp)" to 134102.0
            ), "Horsepower (hp)" to mapOf(
                "Watts (W)" to 745.7,
                "Kilowatts (kW)" to 0.7457,
                "Megawatts (MW)" to 0.0007457,
                "Gigawatts (GW)" to 0.0000007457
            )
        ), "Digital Storage" to mapOf(
            "Bits (b)" to mapOf(
                "Bytes (B)" to 0.125,
                "Kilobytes (KB)" to 0.000125,
                "Megabytes (MB)" to 0.000000125,
                "Gigabytes (GB)" to 0.000000000125,
                "Terabytes (TB)" to 0.000000000000125,
                "Petabytes (PB)" to 0.000000000000000125
            ), "Bytes (B)" to mapOf(
                "Bits (b)" to 8.0,
                "Kilobytes (KB)" to 0.001,
                "Megabytes (MB)" to 0.000001,
                "Gigabytes (GB)" to 0.000000001,
                "Terabytes (TB)" to 0.000000000001,
                "Petabytes (PB)" to 0.000000000000001
            ), "Kilobytes (KB)" to mapOf(
                "Bits (b)" to 8192.0,
                "Bytes (B)" to 1024.0,
                "Megabytes (MB)" to 0.001,
                "Gigabytes (GB)" to 0.000001,
                "Terabytes (TB)" to 0.000000001,
                "Petabytes (PB)" to 0.000000000001
            ), "Megabytes (MB)" to mapOf(
                "Bits (b)" to 8388608.0,
                "Bytes (B)" to 1048576.0,
                "Kilobytes (KB)" to 1024.0,
                "Gigabytes (GB)" to 0.001,
                "Terabytes (TB)" to 0.000001,
                "Petabytes (PB)" to 0.000000001
            ), "Gigabytes (GB)" to mapOf(
                "Bits (b)" to 8589934592.0,
                "Bytes (B)" to 1073741824.0,
                "Kilobytes (KB)" to 1048576.0,
                "Megabytes (MB)" to 1024.0,
                "Terabytes (TB)" to 0.001,
                "Petabytes (PB)" to 0.000001
            ), "Terabytes (TB)" to mapOf(
                "Bits (b)" to 8796093022208.0,
                "Bytes (B)" to 1099511627776.0,
                "Kilobytes (KB)" to 1073741824.0,
                "Megabytes (MB)" to 1048576.0,
                "Gigabytes (GB)" to 1024.0,
                "Petabytes (PB)" to 0.001
            ), "Petabytes (PB)" to mapOf(
                "Bits (b)" to 9007199254740992.0,
                "Bytes (B)" to 1125899906842624.0,
                "Kilobytes (KB)" to 1099511627776.0,
                "Megabytes (MB)" to 1073741824.0,
                "Gigabytes (GB)" to 1048576.0,
                "Terabytes (TB)" to 1024.0
            )
        ), "Fuel Consumption" to mapOf(
            "Liters per 100 kilometers (L/100km)" to mapOf(
                "Miles per gallon (MPG, US)" to 0.02612244897959,
                "Miles per gallon (MPG, UK)" to 0.02112743643636,
                "Kilometers per liter (km/L)" to 100.0
            ), "Miles per gallon (MPG, US)" to mapOf(
                "Liters per 100 kilometers (L/100km)" to 38.00625,
                "Miles per gallon (MPG, UK)" to 0.8327,
                "Kilometers per liter (km/L)" to 4.284
            ), "Miles per gallon (MPG, UK)" to mapOf(
                "Liters per 100 kilometers (L/100km)" to 45.473,
                "Miles per gallon (MPG, US)" to 1.20095,
                "Kilometers per liter (km/L)" to 5.106
            ), "Kilometers per liter (km/L)" to mapOf(
                "Liters per 100 kilometers (L/100km)" to 0.01,
                "Miles per gallon (MPG, US)" to 0.23395,
                "Miles per gallon (MPG, UK)" to 0.19635
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Change top bar color
        val window: Window = window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = resources.getColor(R.color.header_color)

        inputEditText = findViewById(R.id.input_value)
        fromUnitSpinner = findViewById(R.id.from_unit_spinner)
        toUnitSpinner = findViewById(R.id.to_unit_spinner)
        categorySpinner = findViewById(R.id.category_spinner)
        convertButton = findViewById(R.id.convert_button)
        resultTextView = findViewById(R.id.result_textview)

        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = categoryAdapter

        categorySpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>, view: View, position: Int, id: Long
            ) {
                val selectedCategory = categories[position]
                val unitAdapter = ArrayAdapter(
                    this@MainActivity,
                    android.R.layout.simple_spinner_item,
                    units[selectedCategory]!!
                )
                unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                fromUnitSpinner.adapter = unitAdapter
                toUnitSpinner.adapter = unitAdapter
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Do nothing
            }
        }

        convertButton.setOnClickListener {
            val inputValueStr = inputEditText.text.toString()
            if (inputValueStr.isNotEmpty()) {
                val inputValue = inputValueStr.toDoubleOrNull()
                if (inputValue != null) {
                    val fromUnit = fromUnitSpinner.selectedItem.toString()
                    val toUnit = toUnitSpinner.selectedItem.toString()
                    val selectedCategory = categorySpinner.selectedItem.toString()
                    val conversionFactor = conversions[selectedCategory]?.get(fromUnit)?.get(toUnit)

                    if (conversionFactor != null) {

                        // Perform the conversion calculation
                        val result = when (conversionFactor) {
                            is Double -> inputValue * conversionFactor
                            is Float -> inputValue * conversionFactor.toDouble()
                            is Int -> inputValue * conversionFactor.toDouble()
                            is Long -> inputValue * conversionFactor.toDouble()
                            is Short -> inputValue * conversionFactor.toDouble()
                            is Byte -> inputValue * conversionFactor.toDouble()
                            is BigInteger -> inputValue * conversionFactor.toDouble()
                            is BigDecimal -> inputValue * conversionFactor.toDouble()
                            else -> {
                                resultTextView.text = "Unsupported conversion factor type"
                                return@setOnClickListener/*
                                                                try {
                                                                    throw UnsupportedOperationException("Unsupported conversion factor type")
                                                                } catch (e: Exception) {
                                                                    Log.e("e1021", "$e")
                                                                    resultTextView.text =
                                                                        "Unsupported conversion factor type: ${e}"
                                                                    return@setOnClickListener
                                                                }
                                */
                            }
                        }
                        resultTextView.text = "$result $toUnit"
                    } else {
                        resultTextView.text = "Conversion factor not found"
                    }
                } else {
                    resultTextView.text = "Invalid input"
                }
            } else {
                resultTextView.text = "Please enter a value"
            }
        }
    }
}